#!/usr/bin/python
import modules as MOD

#only run if it is main
if __name__ == "__main__":

   #MOD.createLogFilePath()
   #MOD.raspBootWait()
   #MOD.initSPI()
   #MOD.setupPIC24RTC()
   #MOD.collectTimeStampData()
   #MOD.closeSPI()

   #MOD.resetPic24()
   MOD.resetSystem()
	
